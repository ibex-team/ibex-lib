#!/bin/bash
#* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *#
#*                                                                           *#
#*                  This file is part of the class library                   *#
#*       SoPlex --- the Sequential object-oriented simPlex.                  *#
#*                                                                           *#
#*  Copyright (c) 1996-2026 Zuse Institute Berlin (ZIB)                      *#
#*                                                                           *#
#*  Licensed under the Apache License, Version 2.0 (the "License");          *#
#*  you may not use this file except in compliance with the License.         *#
#*  You may obtain a copy of the License at                                  *#
#*                                                                           *#
#*      http://www.apache.org/licenses/LICENSE-2.0                           *#
#*                                                                           *#
#*  Unless required by applicable law or agreed to in writing, software      *#
#*  distributed under the License is distributed on an "AS IS" BASIS,        *#
#*  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *#
#*  See the License for the specific language governing permissions and      *#
#*  limitations under the License.                                           *#
#*                                                                           *#
#*  You should have received a copy of the Apache-2.0 license                *#
#*  along with SoPlex; see the file LICENSE. If not email soplex@zib.de.     *#
#*                                                                           *#
#* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *#

# configures environment variables for cluster runs.
# to be invoked inside a check_cluster.sh script
# This script cancels the process if required variables are not correctly set

# input variables - should be passed to this script
# QUEUE     # the name of the cluster queue
# PPN       # number of cluster nodes to use
# EXCLUSIVE # should cluster nodes be blocked for other users while the jobs are running?
# QUEUETYPE # either 'srun' or 'qsub'

# new environment variables defined by this script:
#   NICE            - cluster job nice flag
#   ACCOUNT         - cluster job account flag
#   CLUSTERQUEUE    - resolved cluster partition
#   CONSTRAINT      - node feature constraint
#   CPUFREQ         - cpu frequency request for reproducible timing
#   TARGETFREQ      - target frequency (kHz) for time normalization
#   EXCLUSIVE       - exclusive sbatch flag
#   AUTO_PPN_PENDING - whether instances-per-node has to be computed automatically

# check if queue has been defined
if test "${QUEUE}" = ""
then
    echo "Skipping test since the queue name has not been defined."
    exit 1
fi

# check if number of nodes has been defined
if test "${PPN}" = ""
then
    echo "Skipping test since the number of nodes has not been defined."
    exit 1
fi

# check whether there is enough memory on the host system, otherwise we need to submit from the target system
if test "${QUEUETYPE}" = "srun"
then
    HOSTMEM=$(ulimit -m)
    if test "${HOSTMEM}" != "unlimited"
    then
        if [ $((HARDMEMLIMIT * 1024)) -gt "${HOSTMEM}" ]
        then
            echo "Not enough memory on host system - please submit from target system (e.g. ssh opt201)."
            exit 1
        fi
    fi

    # use medium frequency with Performance governor if available
    if scontrol show config 2>/dev/null | grep -qE '^CpuFreqGovernors\b.*\bPerformance\b'
    then
        CPUFREQ="medium-medium:Performance"
    else
        CPUFREQ="medium-medium"
    fi
fi

CLUSTERQUEUE="${QUEUE}"
CONSTRAINT=""
NICE=""
ACCOUNT=""

if [ "${CLUSTERQUEUE}" = "moskito" ] || [ "${CLUSTERQUEUE}" = "prio" ]; then
    ACCOUNT="dopt"
elif [[ "$(uname -n)" =~ htc ]]; then
    ACCOUNT=$(sshare -U -P --noheader --format=Account | head -n 1)
fi

if test "${CLUSTERQUEUE}" = "M640v2-low"
then
    NICE="--nice=10000"
    CLUSTERQUEUE="M640v2"
fi

if test "${CLUSTERQUEUE}" = "M640v2"
then
    CONSTRAINT="Gold5222"
    CLUSTERQUEUE="opt_int"
    ACCOUNT="optimi_integer"
    TARGETFREQ=2528567
elif test "${CLUSTERQUEUE}" = "R740"
then
    CONSTRAINT="Gold6246"
    CLUSTERQUEUE="high-mem"
    TARGETFREQ=3300000
elif test "${CLUSTERQUEUE}" = "C6520"
then
    CONSTRAINT="Gold6338"
    CLUSTERQUEUE="big"
    TARGETFREQ=1980945
    # exclude nodes with broken frequency scaling
    test "${EXCLUDENODES}" = "none" && EXCLUDENODES=""
    EXCLUDENODES="htc-cmp[101-102],htc-cmp104,htc-cmp126,htc-cmp[145-148]${EXCLUDENODES:+,${EXCLUDENODES}}"
elif test "${CLUSTERQUEUE}" = "R650"
then
    CONSTRAINT="Gold6342"
    CLUSTERQUEUE="big"
    TARGETFREQ=2128567
elif test "${CLUSTERQUEUE}" = "R7525"
then
    CONSTRAINT="EPYC7542"
    CLUSTERQUEUE="big"
    TARGETFREQ=2900000
elif test "${CLUSTERQUEUE}" = "R7525X"
then
    CONSTRAINT="EPYC7773X"
    CLUSTERQUEUE="high-mem"
    TARGETFREQ=1900000
elif test "${CLUSTERQUEUE}" = "small"
then
    if [ "${DEBUGTOOL}" == "rr" ] || [ "${DEBUGTOOL}" == "perf" ]
    then
        # exclude nodes that don't have access to hardware performance counters enabled
        test "${EXCLUDENODES}" = "none" && EXCLUDENODES=""
        EXCLUDENODES="htc-cmp[220-229]${EXCLUDENODES:+,${EXCLUDENODES}}"
    fi
    if [ "${DEBUGTOOL}" == "rr" ]
    then
        # rr does not run reliably on AMD Zen CPUs, so restrict to Intel nodes
        CONSTRAINT="Intel"
    fi
fi

# check if the slurm blades should be used exclusively
if test "${EXCLUSIVE}" = "true"
then
    EXCLUSIVE=" --exclusive"
    AUTO_PPN_PENDING=0
elif test "${EXCLUSIVE}" = "auto"
then
    EXCLUSIVE=" --exclusive"
    AUTO_PPN_PENDING=1
else
    EXCLUSIVE=""
    AUTO_PPN_PENDING=0
fi
