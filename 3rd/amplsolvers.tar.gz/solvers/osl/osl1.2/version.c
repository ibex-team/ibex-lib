char osl_vers[] = "\nAMPL/OSL Version 19970501\n";
