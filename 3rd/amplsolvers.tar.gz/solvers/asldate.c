long ASLdate_ASL = 20080808;
