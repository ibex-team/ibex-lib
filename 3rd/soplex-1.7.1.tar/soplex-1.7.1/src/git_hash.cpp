#define SPX_GITHASH "b7affa1"
