#include "asl.h"

 void
mpec_adjust_ASL(ASL *asl)
{}	/* do nothing */
