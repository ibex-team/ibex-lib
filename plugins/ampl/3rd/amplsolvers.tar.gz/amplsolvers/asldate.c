long ASLdate_ASL = 20170722;
