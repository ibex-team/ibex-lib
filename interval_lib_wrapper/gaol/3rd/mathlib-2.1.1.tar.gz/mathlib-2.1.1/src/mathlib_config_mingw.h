/* -*-C-*- */
#define HAVE_DLFCN_H 1

/* Name of package */
#undef PACKAGE
#define PACKAGE "mathlib"

/* Version number of package */
#define VERSION "0.0.1"

#define MATHLIB_MINGW 1
