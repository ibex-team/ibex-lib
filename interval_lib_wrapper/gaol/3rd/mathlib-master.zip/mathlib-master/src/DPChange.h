#include "mathlib_config.h"

#if defined(_MSC_VER) || defined(__BORLANDC__)
#   include "MSVC_DPChange.h"
#else
#   include "LINUX_DPChange.h"
#endif
